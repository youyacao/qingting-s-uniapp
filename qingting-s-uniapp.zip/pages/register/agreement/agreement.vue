<!-- 
All rights Reserved, Designed By www.youyacao.com 
@Description:同意条款
@author:成都市一颗优雅草科技有限公司     
@version 蜻蜓S系统 前端源码 
注意：本前端源码遵循开源条款
详情访问：https://songshu.youyacao.com/detail/244.html
本内容仅限于个人参考，禁止用于其他的商业用途
需要商业用途或者定制开发等可访问songshu.youyacao.com   联系QQ:422108995 23625059584

 -->





<template>
	<view class="body">
		<web-view :webview-styles="webviewStyles" src="https://songshu.youyacao.com/detail/225.html"></web-view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				webviewStyles: {}
			};
		}
	}
</script>

<style lang="scss" scoped>

</style>
