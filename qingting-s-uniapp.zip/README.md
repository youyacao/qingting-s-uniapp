# 蜻蜓S系统uniapp版本前端

#### 介绍
蜻蜓S系统是一款由成都市一颗优雅草科技有限公司团队自主研发，可自由二次开发的vue+nvue+uniapp+java/php双版本的系统，前后端分离性能卓越的系统，包含直播，短视频，图文，影视，社交，ui--美颜对接上海涂图原生sdk的综合型短视频+直播+系统，蜻蜓系统逐步全面开源，如果对您有帮助，希望给个小星星鼓励，感谢支持。
#### 蜻蜓系列软件架构

vue + nuve +uniapp +flutter + java + php +laravel

node.js +springboot2.2+springmvc+druid+mybatis+mangoDB+mysql+shiro-redis+redis+activemq

此库为蜻蜓s前端，蜻蜓s前端使用vue+nuve+uniapp
 
 
 其他版本请关注松鼠/蜻蜓系统管网 

[松鼠短视频](https://songshu.youyacao.com/video.html)}
[蜻蜓系统](https://qingting.youyacao.com/video.html)}

#### 安装教程

[蜻蜓系统整体安装教程](https://doc.youyacao.com/web/#/8?page_id=51)


#### 文件目录说明

[蜻蜓S系统官方目录说明](https://doc.youyacao.com/web/#/8?page_id=649)}



#### API接口文档

[点击查看API接口文档](https://doc.youyacao.com/web/#/16?page_id=93)}


#### 购买授权或技术支持

正版授权管网查询：

[点击查询授权以及购买其他技术支持服务](https://zhengban.youyacao.com)}


官方QQ交流群：929353806